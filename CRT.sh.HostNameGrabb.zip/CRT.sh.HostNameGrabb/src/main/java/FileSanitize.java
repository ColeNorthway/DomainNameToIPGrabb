import java.io.IOException;
import java.time.Duration;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.io.FileWriter;
import java.util.Scanner;



public class FileSanitize {
    private String filePath;
    private String filePath2;
    
    public FileSanitize() {
        this.filePath = "Domains Results.txt";
        this.filePath2 = "Revised Domain Results.txt";
        
    }
    
    
    
    public void fileSanitize() {
        Boolean add = true;
        
        try (Scanner scanner = new Scanner(Paths.get(filePath))) {
            
            Thread.sleep(1000);
            System.out.println("Sanitizing Now");
            Thread.sleep(2000);
            
            while(scanner.hasNextLine()) {
                String line0 = scanner.nextLine();
                
                try(Scanner scan = new Scanner(Paths.get(filePath2))) {
                    
                    while(scan.hasNextLine()){
                        
                        String line1 = scan.nextLine();
                        
                        if(line0.equals(line1)){
                            add = false;
                            break;
                        } else {
                            add = true;
                        }
                                
                    }
                }
                
                if (add) {
                    try(FileWriter writer = new FileWriter(filePath2, true)){
                        writer.write(line0 + "\n");
                        System.out.println("Line has been sanitized!");
                    }  
                    
                }

            }  
            
        } catch (Exception e) {
            System.out.println("An error occured while trying to read from file");
            e.printStackTrace();
        }
        
    }
    
}
