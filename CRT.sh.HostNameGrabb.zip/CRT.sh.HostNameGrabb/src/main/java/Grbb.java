import java.io.IOException;
import java.net.URI;
import java.net.http.HttpResponse;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse.BodyHandlers;
import java.nio.file.Paths;
import java.nio.file.Path;
import java.util.Scanner;
import java.net.http.HttpClient;
import java.net.http.HttpClient.Redirect;
import java.net.http.HttpClient.Version;
import java.time.Duration;


public class Grbb {
    private String filePath;
    
    public Grbb() {
        this.filePath = "SSL Cert Domain Results.txt";
    }
    
    
    
    public void grbb() {
        
        Scanner scanner = new Scanner(System.in);
        System.out.println("Insert Domain Below");
        String domain = scanner.nextLine();
        
        
        HttpClient webClient = HttpClient.newBuilder()
                .version(Version.HTTP_1_1)
                .followRedirects(Redirect.NORMAL)
                .connectTimeout(Duration.ofSeconds(20))
                .build();
        
        HttpRequest request = HttpRequest.newBuilder()
                .uri(URI.create("https://crt.sh/json?q=" + domain))
                .build();
        
        try {
            HttpResponse<Path> response = webClient.send(request, BodyHandlers.ofFile(Paths.get(filePath)));
            System.out.println(response.statusCode());
            Thread.sleep(3000);
        } catch (IOException e) {
            System.err.println("I/O error occurred (grbb) : " + e.getMessage());
        } catch (InterruptedException q) {
            System.err.println("Request was interrupted (grbb) " + q.getMessage());
            Thread.currentThread().interrupt();
        } 
        
    }
            
}
