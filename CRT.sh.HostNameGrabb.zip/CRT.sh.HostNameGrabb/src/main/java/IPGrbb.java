import java.net.InetAddress;
import java.util.Scanner;
import java.io.FileWriter;
import java.io.IOException;
import java.nio.file.Paths;
import java.net.UnknownHostException;


public class IPGrbb {
    private String filePath0;
    private String filePath1;
    
    
    public IPGrbb(){
        this.filePath0 = "Revised Domain Results.txt";
        this.filePath1 = "IP Results.txt";
    }
    
    
    public void ipGrbb(){
        
        try(Scanner scanner = new Scanner(Paths.get(this.filePath0))) {
            
            while(scanner.hasNextLine()){
                String line = scanner.nextLine();
                
                try(FileWriter writer = new FileWriter(filePath1, true)){
                    
                    if(line.indexOf("*") == 0){
                        String lineRevised = line.substring(2);
                        
                        try {
                            InetAddress grbbIPRevised = InetAddress.getByName(lineRevised);
                        
                            writer.write(grbbIPRevised.getHostAddress() + " : " + lineRevised + "\n");
                            
                            System.out.println("IP and Host added");
                            
                        } catch (UnknownHostException e){
                            
                            System.out.println("Host not found");
                            e.printStackTrace();
                        }
                        
                    } else {
                        
                        try {
                            InetAddress grbbIPRevised = InetAddress.getByName(line);
                        
                            writer.write(grbbIPRevised.getHostAddress() + " : " + line + "\n");
                            
                            System.out.println("IP and Host added");
                            
                        } catch (UnknownHostException e){
                            
                            System.out.println("Host not found");
                            e.printStackTrace();
                        }
                                              
                    }  
                    
                } catch (IOException e){
                    System.out.println("The file wasn't able to write or host unable to be resonved(IPGrbb)");
                    e.printStackTrace();
                }
                

            }
        } catch(Exception e){
            System.out.println("The file was not able to be read (IPGrbb)");
            e.printStackTrace();
        }
        
    }
}

/*
                if(line.indexOf("*") == 0){
                    String lineRevised = line.substring(2);
                    InetAddress grbbIPRevised = InetAddress.getByName(lineRevised);
                    
                    
                    
                } else {
                    InetAddress grbbIP = InetAddress.getByName(line);
                }
                
*/