public class DmnNmeGrbb {
    
    public static void main(String[] args) {
        
        Grbb grabb = new Grbb();
        FileAdd fileAdder = new FileAdd();
        FileSanitize sanitizer = new FileSanitize();
        IPGrbb ipGrbb = new IPGrbb();
        
        
        grabb.grbb();
        fileAdder.fileAdd();
        sanitizer.fileSanitize();
        ipGrbb.ipGrbb();
        
    }
}
