import java.util.Scanner;
import java.io.FileWriter;
import java.nio.file.Paths;
import java.io.IOException;


public class FileAdd {
    private String filePath;
    private String filePath2;
    
    
    public FileAdd() {
        this.filePath = "SSL Cert Domain Results.txt";
        this.filePath2 = "Domains Results.txt";
    }
    
    
    
    public void fileAdd() {
        try (Scanner scanner = new Scanner(Paths.get(filePath))){

            while(scanner.hasNextLine()){
                String line = scanner.nextLine();
                String[] pieces = line.split(",");

                for(String piece : pieces){
                    
                    if(piece.contains("name_value")){
                        
                        String[] hostNameSplit = piece.split("\"");

                        try (FileWriter writer = new FileWriter(filePath2, true)){
                            writer.write(hostNameSplit[3] + "\n");
                            System.out.println("Text added to the file successfully!");
                        } catch (IOException e) {
                            System.out.println("An error occured while writing to the file. (FileAdd)");
                            e.printStackTrace();
                        }
                        
                    }
                    
                }
                
            }
            
        } catch (Exception e){
            System.out.println("An error occured while trying to read from the file. (FileAdd)");
            e.printStackTrace();
        }
    }
}
